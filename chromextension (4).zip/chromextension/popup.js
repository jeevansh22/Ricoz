document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('saveLang').addEventListener('click', function () {
    const selectedLang = document.getElementById('langSelect').value;

    // Save the selected language in Chrome's storage
    chrome.storage.sync.set({ preferredLanguage: selectedLang }, function () {
      console.log('Preferred language saved: ' + selectedLang);
      alert('Language saved: ' + selectedLang);
    });
  });
});
