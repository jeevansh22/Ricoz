// Fetch user's preferred language from storage
chrome.storage.sync.get("preferredLanguage", ({ preferredLanguage }) => {
  console.log("Preferred language:", preferredLanguage);

  // Select the chat container
  const chatContainer = document.querySelector("#pane-side"); // Adjust if necessary

  // Observe chat messages for changes
  const observer = new MutationObserver((mutationsList) => {
      mutationsList.forEach(mutation => {
          if (mutation.addedNodes.length) {
              const newMessageNode = mutation.addedNodes[0];
              const newMessage = newMessageNode.innerText;

              console.log("New message detected:", newMessage); // Log the new message

              // Translate the new message
              translateMessage(newMessage, preferredLanguage, (translatedText) => {
                  console.log("Translated text:", translatedText); // Log the translated text
                  // Replace the message with the translated version
                  newMessageNode.innerText = translatedText;
              });
          }
      });
  });

  // Start observing the chat container for new messages
  if (chatContainer) {
      observer.observe(chatContainer, { childList: true, subtree: true });
  } else {
      console.error("Chat container not found!");
  }
});

// Function to translate messages using AllThingsDev API
function translateMessage(text, targetLang, callback) {
  const apiUrl = 'https://Content-and-Marketing-Advanced-Text-Translator.proxy-production.allthingsdev.co/api/v1/content/translate';

  const myHeaders = new Headers();
  myHeaders.append("Accept", "application/json");
  myHeaders.append("x-apihub-key", "CARMHqkrX4I9ykTIXjrGPBsCmu-hiGZXGPBJjfqeEF9wBJ56-Q");
  myHeaders.append("x-apihub-host", "Content-and-Marketing-Advanced-Text-Translator.allthingsdev.co");
  myHeaders.append("x-apihub-endpoint", "24f49ff4-4f31-46e7-8d58-397e5b3f52a5");

  const raw = JSON.stringify({
      content: text,
      language: targetLang,  // The target language selected by the user
      voice_tone: "neutral",
      context: null
  });

  const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow"
  };

  fetch(apiUrl, requestOptions)
      .then(response => {
          console.log("Response Status:", response.status); // Log the response status
          return response.json(); // Ensure response is in JSON format
      })
      .then(data => {
          console.log("API Response Data:", data); // Log the API response data
          const translatedText = data.translated_text || 'Translation error'; // Adjust based on the actual response key
          callback(translatedText);
      })
      .catch(error => {
          console.error('Translation error:', error);
          callback('Error in translation');
      });
}
