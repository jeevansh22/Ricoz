chrome.runtime.onInstalled.addListener(() => {
    console.log("WhatsApp Translator Extension Installed");
  });
  